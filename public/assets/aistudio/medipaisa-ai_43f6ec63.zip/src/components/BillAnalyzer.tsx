import React, { useState, useRef } from 'react';
import {
  Upload,
  ScanLine,
  CheckCircle2,
  AlertCircle,
  FileText,
  Sparkles,
  Receipt,
  Plus,
  Trash2,
  Edit2,
  ArrowRight,
  Eye,
  RefreshCw,
  Clock,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { useExpenses } from '../context/ExpenseContext';
import { BillAnalysisResult, LineItem, ExpenseCategory } from '../types';
import { formatINR, formatINRDecimal, getTodayDateString } from '../utils/formatters';
import { createSampleBillImage } from '../data/sampleData';

const CATEGORIES: ExpenseCategory[] = [
  'Medicines',
  'Doctor Consultation',
  'Laboratory Tests',
  'Hospitalization',
  'Other',
];

export const BillAnalyzer: React.FC = () => {
  const { addExpense, setActiveTab } = useExpenses();

  const [file, setFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<BillAnalysisResult | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Editable review form state
  const [vendorName, setVendorName] = useState('');
  const [billDate, setBillDate] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>('Medicines');
  const [lineItems, setLineItems] = useState<LineItem[]>([]);
  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [subtotal, setSubtotal] = useState<number>(0);
  const [taxAmount, setTaxAmount] = useState<number>(0);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [notes, setNotes] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle file select (local image or PDF converted)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      setFile(selected);
      setErrorMessage(null);
      setAnalysisResult(null);

      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(selected);
    }
  };

  // Load one of the 3 pre-built realistic Indian Medical Bill templates for instant testing
  const loadPresetBill = (type: 'apollo' | 'lalpath' | 'fortis') => {
    const sample = createSampleBillImage(type);
    setImagePreview(sample.dataUri);
    setFile(null);
    setErrorMessage(null);
    setAnalysisResult(null);
  };

  // Run AI analysis
  const handleAnalyzeBill = async () => {
    if (!imagePreview) {
      setErrorMessage('Please select or upload a medical bill first.');
      return;
    }

    setIsAnalyzing(true);
    setErrorMessage(null);
    setAnalysisResult(null);

    try {
      const mimeType = imagePreview.startsWith('data:image/png')
        ? 'image/png'
        : imagePreview.startsWith('data:image/webp')
        ? 'image/webp'
        : 'image/jpeg';

      const res = await fetch('/api/gemini/analyze-bill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imagePreview,
          mimeType,
          filename: file?.name || 'medical-bill-scan.png',
        }),
      });

      const json = await res.json();

      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Failed to extract bill information.');
      }

      const result: BillAnalysisResult = json.data;
      setAnalysisResult(result);

      // Populate editable review form
      setVendorName(result.vendorName || '');
      setBillDate(result.billDate || getTodayDateString());
      setInvoiceNumber(result.invoiceNumber || '');
      setCategory(result.category || 'Medicines');
      setLineItems(result.lineItems || []);
      setTotalAmount(result.totalAmount || result.itemsSum || 0);
      setSubtotal(result.subtotal || 0);
      setTaxAmount(result.taxAmount || 0);
      setDiscountAmount(result.discountAmount || 0);
      setNotes(result.confidenceNotes || '');
    } catch (err: any) {
      console.error(err);
      setErrorMessage(
        err.message || 'An error occurred while communicating with MediPaisa AI Bill OCR.'
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Line items editing helpers
  const handleUpdateLineItem = (index: number, field: keyof LineItem, value: any) => {
    const updated = [...lineItems];
    updated[index] = { ...updated[index], [field]: value };
    setLineItems(updated);

    // Auto update total if items changed
    const newSum = updated.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    setTotalAmount(newSum);
  };

  const handleAddLineItem = () => {
    setLineItems([...lineItems, { description: 'New Medicine/Test', quantity: 1, amount: 100 }]);
  };

  const handleRemoveLineItem = (index: number) => {
    const updated = lineItems.filter((_, i) => i !== index);
    setLineItems(updated);
    const newSum = updated.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
    setTotalAmount(newSum);
  };

  // Math consistency check in review form
  const computedItemsSum = lineItems.reduce((acc, it) => acc + (Number(it.amount) || 0), 0);
  const mathMatches = Math.abs(computedItemsSum - totalAmount) < 1.0;

  // Save to expense ledger
  const handleSaveToExpenses = () => {
    if (!totalAmount || totalAmount <= 0) {
      setErrorMessage('Total amount must be greater than ₹0.');
      return;
    }

    const title =
      lineItems.length > 0 && lineItems[0].description
        ? `${vendorName || category} - ${lineItems[0].description}${
            lineItems.length > 1 ? ` (+${lineItems.length - 1} items)` : ''
          }`
        : `${vendorName || 'Medical Bill'}`;

    addExpense({
      name: title,
      amount: totalAmount,
      category,
      date: billDate || getTodayDateString(),
      vendor: vendorName || undefined,
      notes: notes ? `${notes} (Invoice #${invoiceNumber})` : `Invoice #${invoiceNumber}`,
      billData: {
        invoiceNumber,
        lineItems,
        subtotal,
        taxAmount,
        discountAmount,
        extractedAt: new Date().toISOString(),
        isMathConsistent: mathMatches,
      },
    });

    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      setActiveTab('expenses');
    }, 1200);
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              AI Medical Bill & Receipt Analyzer
            </h1>
            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
              Gemini 3.8 Flash Multimodal OCR
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Upload any Indian pharmacy cash memo, doctor OPD slip, lab diagnostic invoice, or hospital bill to extract itemized medicine lines and verify math totals.
          </p>
        </div>
      </div>

      {/* Main Grid: Upload & Preview (5 cols) + Extracted Review (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Upload & Instant Presets (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-teal-600" />
              <span>Upload Medical Bill or Receipt</span>
            </h3>

            {/* Dropzone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-slate-300 hover:border-teal-500 rounded-2xl p-6 text-center cursor-pointer transition bg-slate-50/50 hover:bg-teal-50/20 group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />
              <div className="w-12 h-12 rounded-xl bg-teal-100/70 text-teal-700 flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                <Receipt className="w-6 h-6" />
              </div>
              <div className="text-xs font-bold text-slate-800">
                Click to browse or drop bill image
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Supports PNG, JPG, WebP photos of receipts
              </div>
            </div>

            {/* Quick Presets for Instant Testing */}
            <div>
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">
                Instant Presets (Try with real Indian bills):
              </div>
              <div className="grid grid-cols-1 gap-2">
                <button
                  type="button"
                  onClick={() => loadPresetBill('apollo')}
                  className="w-full px-3 py-2 rounded-xl border border-teal-200 bg-teal-50/60 hover:bg-teal-100/70 text-left transition flex items-center justify-between text-xs cursor-pointer group"
                >
                  <div>
                    <div className="font-bold text-teal-900">Apollo Pharmacy Cash Memo</div>
                    <div className="text-[10px] text-teal-700">Chronic medicines (Glycomet, Telma, Atorva) • ₹1,845</div>
                  </div>
                  <Sparkles className="w-4 h-4 text-teal-600 group-hover:rotate-12 transition-transform" />
                </button>

                <button
                  type="button"
                  onClick={() => loadPresetBill('lalpath')}
                  className="w-full px-3 py-2 rounded-xl border border-rose-200 bg-rose-50/60 hover:bg-rose-100/70 text-left transition flex items-center justify-between text-xs cursor-pointer group"
                >
                  <div>
                    <div className="font-bold text-rose-900">Dr. Lal PathLabs Diagnostic Receipt</div>
                    <div className="text-[10px] text-rose-700">HbA1c, Lipid Profile, KFT Tests • ₹2,650</div>
                  </div>
                  <Sparkles className="w-4 h-4 text-rose-600 group-hover:rotate-12 transition-transform" />
                </button>

                <button
                  type="button"
                  onClick={() => loadPresetBill('fortis')}
                  className="w-full px-3 py-2 rounded-xl border border-indigo-200 bg-indigo-50/60 hover:bg-indigo-100/70 text-left transition flex items-center justify-between text-xs cursor-pointer group"
                >
                  <div>
                    <div className="font-bold text-indigo-900">Fortis Hospital OPD Invoice</div>
                    <div className="text-[10px] text-indigo-700">Senior Cardiology OPD + 12-Lead ECG • ₹1,500</div>
                  </div>
                  <Sparkles className="w-4 h-4 text-indigo-600 group-hover:rotate-12 transition-transform" />
                </button>
              </div>
            </div>

            {/* Bill Preview Box */}
            {imagePreview && (
              <div className="pt-2">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2">
                  <span>Selected Bill Preview:</span>
                  <button
                    onClick={() => {
                      setImagePreview(null);
                      setFile(null);
                      setAnalysisResult(null);
                    }}
                    className="text-rose-600 hover:underline text-[11px]"
                  >
                    Remove
                  </button>
                </div>
                <div className="rounded-xl border border-slate-200 overflow-hidden max-h-64 bg-slate-900/5 relative flex items-center justify-center p-2">
                  <img
                    src={imagePreview}
                    alt="Medical Bill Preview"
                    className="max-h-60 object-contain rounded-lg shadow-xs"
                  />
                </div>

                {/* Scan Button */}
                <button
                  type="button"
                  disabled={isAnalyzing}
                  onClick={handleAnalyzeBill}
                  className="mt-4 w-full py-3 rounded-xl text-xs sm:text-sm font-bold text-white bg-teal-600 hover:bg-teal-700 shadow-md shadow-teal-600/30 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Gemini AI is reading & auditing bill...</span>
                    </>
                  ) : (
                    <>
                      <ScanLine className="w-4 h-4 stroke-[2.5]" />
                      <span>Extract & Verify with Gemini AI</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Editable Review & Verification (7 cols) */}
        <div className="lg:col-span-7">
          <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Extracted Bill Details</h3>
                <p className="text-xs text-slate-500">
                  Review extracted vendor, date, line items, and audit math before saving.
                </p>
              </div>
              {analysisResult && (
                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-teal-100 text-teal-800">
                  AI Verified
                </span>
              )}
            </div>

            {/* Error Message if any */}
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Extraction Notice</div>
                  <div>{errorMessage}</div>
                </div>
              </div>
            )}

            {/* Empty State before analysis */}
            {!analysisResult && !isAnalyzing && (
              <div className="py-12 text-center text-slate-400">
                <ScanLine className="w-12 h-12 mx-auto mb-2 text-slate-300" />
                <h4 className="text-sm font-bold text-slate-700">No bill scanned yet</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  Upload an image on the left or click one of the instant Indian Presets (Apollo Pharmacy, Dr. Lal PathLabs) to test AI OCR analysis.
                </p>
              </div>
            )}

            {/* Loading Skeleton during analysis */}
            {isAnalyzing && (
              <div className="py-12 text-center space-y-4">
                <div className="w-12 h-12 rounded-full border-4 border-teal-200 border-t-teal-600 animate-spin mx-auto" />
                <div className="text-sm font-bold text-slate-800">
                  Extracting medical items & validating billing amounts...
                </div>
                <div className="text-xs text-slate-500 max-w-xs mx-auto">
                  Running multimodal character recognition, separating prescription items, verifying CGST/SGST and calculating totals.
                </div>
              </div>
            )}

            {/* Analysis Review Form */}
            {analysisResult && (
              <div className="space-y-4 animate-in fade-in duration-200">
                {/* Math Consistency Audit Banner */}
                <div
                  className={`p-3.5 rounded-xl border flex items-center justify-between text-xs ${
                    mathMatches
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                      : 'bg-amber-50 border-amber-200 text-amber-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {mathMatches ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    )}
                    <div>
                      <span className="font-bold">
                        {mathMatches
                          ? 'Mathematical Audit Passed:'
                          : 'Potential Calculation Discrepancy:'}
                      </span>{' '}
                      Line items sum ({formatINR(computedItemsSum)}){' '}
                      {mathMatches
                        ? `matches the bill total (${formatINR(totalAmount)}) perfectly.`
                        : `differs from bill total (${formatINR(totalAmount)}) by ${formatINR(
                            Math.abs(computedItemsSum - totalAmount)
                          )}. Check discounts or taxes below.`}
                    </div>
                  </div>
                </div>

                {/* Form fields: Vendor, Date, Invoice, Category */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Healthcare Provider / Pharmacy
                    </label>
                    <input
                      type="text"
                      value={vendorName}
                      onChange={(e) => setVendorName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium text-slate-900 focus:outline-hidden focus:border-teal-500 focus:ring-1 focus:ring-teal-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Bill / Invoice Date
                    </label>
                    <input
                      type="date"
                      value={billDate}
                      onChange={(e) => setBillDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium text-slate-900 focus:outline-hidden focus:border-teal-500 focus:ring-1 focus:ring-teal-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Invoice / Memo Number
                    </label>
                    <input
                      type="text"
                      value={invoiceNumber}
                      onChange={(e) => setInvoiceNumber(e.target.value)}
                      placeholder="e.g. APO-9921"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium text-slate-900 focus:outline-hidden focus:border-teal-500 focus:ring-1 focus:ring-teal-100"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Category
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-medium text-slate-900 bg-white focus:outline-hidden focus:border-teal-500 focus:ring-1 focus:ring-teal-100"
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Line Items Table */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-bold text-slate-800">
                      Itemized Medicines & Services ({lineItems.length})
                    </label>
                    <button
                      type="button"
                      onClick={handleAddLineItem}
                      className="text-xs text-teal-600 hover:text-teal-700 font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Line
                    </button>
                  </div>

                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                        <tr>
                          <th className="py-2 px-3">Description</th>
                          <th className="py-2 px-2 w-16 text-center">Qty</th>
                          <th className="py-2 px-3 w-28 text-right">Amount (₹)</th>
                          <th className="py-2 px-2 w-10 text-center"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {lineItems.map((item, idx) => (
                          <tr key={idx} className="hover:bg-slate-50/60">
                            <td className="py-2 px-3">
                              <input
                                type="text"
                                value={item.description}
                                onChange={(e) =>
                                  handleUpdateLineItem(idx, 'description', e.target.value)
                                }
                                className="w-full bg-transparent border-b border-transparent focus:border-teal-500 focus:outline-hidden text-slate-800 font-medium"
                              />
                            </td>
                            <td className="py-2 px-2 text-center">
                              <input
                                type="number"
                                min="1"
                                value={item.quantity || 1}
                                onChange={(e) =>
                                  handleUpdateLineItem(idx, 'quantity', parseInt(e.target.value) || 1)
                                }
                                className="w-12 text-center bg-transparent border-b border-transparent focus:border-teal-500 focus:outline-hidden text-slate-800"
                              />
                            </td>
                            <td className="py-2 px-3 text-right">
                              <input
                                type="number"
                                step="any"
                                value={item.amount}
                                onChange={(e) =>
                                  handleUpdateLineItem(idx, 'amount', parseFloat(e.target.value) || 0)
                                }
                                className="w-20 text-right bg-transparent border-b border-transparent focus:border-teal-500 focus:outline-hidden font-bold text-slate-900"
                              />
                            </td>
                            <td className="py-2 px-2 text-center">
                              <button
                                type="button"
                                onClick={() => handleRemoveLineItem(idx)}
                                className="text-slate-400 hover:text-rose-600"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Totals Summary */}
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 flex items-center justify-between">
                  <div className="text-xs text-slate-600">
                    <div>Items Subtotal: <strong>{formatINR(computedItemsSum)}</strong></div>
                    {taxAmount > 0 && <div>Taxes (GST): {formatINR(taxAmount)}</div>}
                    {discountAmount > 0 && <div>Discount: -{formatINR(discountAmount)}</div>}
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-500 block">Total Payable:</span>
                    <span className="text-xl font-extrabold text-teal-700">
                      {formatINR(totalAmount)}
                    </span>
                  </div>
                </div>

                {/* Save button */}
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleSaveToExpenses}
                    className="w-full py-3 rounded-xl text-xs sm:text-sm font-bold text-white bg-teal-600 hover:bg-teal-700 shadow-sm shadow-teal-600/30 transition flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {saveSuccess ? (
                      <>
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Saved to Expenses Ledger!</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4 stroke-[2.5]" />
                        <span>Save to Healthcare Expenses Ledger</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
